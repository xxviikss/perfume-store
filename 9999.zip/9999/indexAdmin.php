<?php
require('connect.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="assets/main.css">
    <link rel="icon" href="assets/images/logo.ico">
</head>
<body>

    <nav class="nav" id="nav">
        <div class="close" id="close">✕</div>
        <p><?php if (isset($_COOKIE['name'])) { echo 'Hi, '.$_COOKIE['name'];} ?></p>
        <a href="index.php">Home</a>
        <a href="login.html">Sign in</a>
        <a href="register.html">Sign up</a>
        <a href="edit.php">Admin capabilities</a>
        <a href="#" id="brandsLink">Brands
            <ul style="margin-left: 18px; display: none;" id="brandsList">
                <li style="margin-bottom: 10px"><a href="brand1.php">Chanel</a></li>
                <li><a href="brand2.php">Bvlgari</a></li>
            </ul>
        </a>
        <a href="cookienull.php"><?php if (isset($_COOKIE['name'])) { echo 'Log out';} ?></a>
    </nav>

    <div class="wrapper">
        <div class="container menu-head">
            <header>
                <div class="menu" id="open">
                    <div class="menu-line"></div>
                    <div class="menu-line"></div>
                    <div class="menu-line"></div>
                </div>
                <a href="index.php" class="logo">W - Arômes</a>
                <div class="svg-icons">
                    <form class="search" action="search.php" method="post">
                        <input type="text" name="Searchbox" class="search-box" placeholder="  Search...">
                        <input type="submit" name="submit" hidden>
                    </form>
                    <div class="search-container">
                        <a><img src="assets//images/search.svg" alt="Search bar"></a>
                    </div>
                    <div class="bag-container">
                        <a href="bag.php"><img src="assets//images/bag.svg" alt="Shopping bag"></a>
                    </div>
                </div>
            </header>
        </div>

        <div class="gray-bg">
            <div class="container">
                <div class="hero hero-mainpage">
                    <div class="content">
                        <h1>New Chanel N°5</h1>
                        <a href="brand1.php" class="link-btn">Learn more</a>
                    </div>
                    <div class="hero-img-container">
                        <img src="assets/images/main.png" alt="">
                    </div>
                </div>
            </div>
        </div>

        <div class="container">
            <div class="item-list-container">
                <h3 class="group-name">Best sellers</h3>
                <div class="item-list-grid">
                    <?php
                    $sql = "SELECT * FROM products WHERE rating='best seller'";
                    $result = mysqli_query($conn,$sql);
                    $article = mysqli_fetch_all($result);
                    if (mysqli_error($conn)) {
                        echo 'the error of mysql '.mysqli_error($conn);
                    }
                    else{
                        for($i=0;$i<count($article);$i++) {
                            print'
                        <form class="item" action="productpage.php" method="post">
                        <input type="text" name="id"  value="' . $article[$i][0] . '" hidden>
                        <button class="overlay-container">
                            <div class="img-overlay">
                                <p>Buy &#8594;</p>
                            </div>
                            <div class="item-img">
                                <img src="'.$article[$i][2].'" alt="">
                            </div>
                        </button>
                        <p class="name">'.$article[$i][3].'</p>
                        <p class="price">'.$article[$i][4].'$</p>
                    </form>';
                        }
                    }
                    ?>

                </div>
            </div>
        </div>

        <div class="container">
            <div class="item-list-container">
                <h3 class="group-name">Our products</h3>
                <div class="item-list-grid">
                    <?php
                        $sql = "SELECT * FROM products WHERE rating!='best seller'";
                        $result = mysqli_query($conn,$sql);
                        $article = mysqli_fetch_all($result);
                        if (mysqli_error($conn)) {
                        echo 'the error of mysql '.mysqli_error($conn);
                        }
                        else{
                            for($i=0;$i<count($article);$i++) {
                                print'
                         <form class="item" action="productpage.php" method="post">
                        <input type="text" name="id"  value="' . $article[$i][0] . '" hidden>
                        <button class="overlay-container">
                            <div class="img-overlay">
                                <p>Buy &#8594;</p>
                            </div>
                            <div class="item-img">
                                <img src="'.$article[$i][2].'" alt="">
                            </div>
                        </button>
                        <p class="name">'.$article[$i][3].'</p>
                        <p class="price">'.$article[$i][4].'$</p>
                    </form>';
                            }
                    }
                    ?>

                </div>
            </div>
        </div>
    </div>

    <div class="black-bg">
        <div class="container">
            <footer>
                <h3 class="logo">W - Arômes</h3>
                <h3>© Аll rights reserved</h3>
            </footer>
        </div>
    </div>

<script src="assets/main.js"></script>
</body>
</html>