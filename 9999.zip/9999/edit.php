<?php
require('connect.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="assets/main.css">
    <link rel="icon" href="assets/images/logo.ico">
</head>
<style>
    .access{
        width: 500px;
        height: 550px;
        padding: 200px 20px;
        font-size:30px;
        margin-left: 315px;
    }
</style>
<body>
    
    <nav class="nav" id="nav">
        <div class="close" id="close">✕</div>
        <p><?php if (isset($_COOKIE['name'])) { echo 'Hi, '.$_COOKIE['name'];} ?></p>
        <a href="index.php">Home</a>
        <a href="login.html">Sign in</a>
        <a href="register.html">Sign up</a>
        <a href="#" id="brandsLink">Brands
            <ul style="margin-left: 18px; display: none;" id="brandsList">
                <li style="margin-bottom: 10px"><a href="brand1.php">Chanel</a></li>
                <li><a href="brand2.php">Bvlgari</a></li>
            </ul>
        </a>
        <a href="cookienull.php"><?php if (isset($_COOKIE['name'])) { echo 'Log out';} ?></a>
    </nav>
    
    <div class="wrapper">
        <div class="container menu-head">
            <header>
                <div class="menu" id="open">
                    <div class="menu-line"></div>
                    <div class="menu-line"></div>
                    <div class="menu-line"></div>
                </div>
                <a href="index.php" class="logo">W - Arômes</a>
                <div class="svg-icons">
                    <input type="text" name="Searchbox" class="search-box" placeholder="  Search...">
                    <div class="search-container">
                        <a><img src="assets//images/search.svg" alt="Search bar"></a>
                    </div>
                    <div class="bag-container">
                        <a href="bag.php"><img src="assets//images/bag.svg" alt="Shopping bag"></a>
                    </div>
                </div>
            </header>
        </div>
        <?php if(isset($_COOKIE['user_id'])) {
            print'<div>
            <div class="admin-text gray-bg">
                <h1>admin capabilities</h1>
            </div>
            <div class="adminskills container">
                <a href="admin/addAdmin.html">Add new admin</a>
                <a href="admin/addproduct.html">Add product</a>
                <a href="admin/preupdate.php">Update product</a>
                <a href="admin/preupdate.php ">Delete product</a>
            </div>           
        </div>';
        }
        else{
            print'<div class="access">To access the admin capabilities <a href="login.html">log in</a> as admin</div>';
        }
    ?>
        
    </div>

    <div class="black-bg">
        <div class="container">
            <footer>
                <h3 class="logo">W - Arômes</h3>
                <h3>© Аll rights reserved</h3>
            </footer>
        </div>
    </div>

<script src="assets/main.js"></script>
</body>
</html>