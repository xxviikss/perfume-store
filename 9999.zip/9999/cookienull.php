<?php
if (isset($_COOKIE['user_id'])) {
    unset($_COOKIE['user_id']);
    unset($_COOKIE['name']);
    unset($_COOKIE['admin']);
    setcookie('user_id', '', time() - 3600, '/'); // empty value and old timestamp
    setcookie('name', '', time() - 3600, '/'); // empty value and old timestamp
    setcookie('admin', '', time() - 3600, '/'); // empty value and old timestamp
}
header('location:login.html');

?>

