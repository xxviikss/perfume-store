<?php
require ('../connect.php');

if (isset($_POST['submit'])) {
    $prod_name = $_POST['prod_name'];
    $prod_img = $_POST['prod_img'];
    $price = $_POST['price'];
    $brand = $_POST['brand'];
    $description = $_POST['description'];
    $prod_img = $_POST['prod_img'];
    $rating = $_POST['rating'];
    $sql = "INSERT INTO products (description, prod_img, prod_name, price, brand, rating) VALUES ('" . $description . "', '" . $prod_img . "', '" . $prod_name . "', '" . $price . "', '" . $brand . "', '" . $rating . "')";
    $result = mysqli_query($conn, $sql);
    if (mysqli_error($conn)) {
        echo 'the error of mysql ' . mysqli_error($conn);
    } else {
        header('Location: ../indexAdmin.php');
    }
}
?>