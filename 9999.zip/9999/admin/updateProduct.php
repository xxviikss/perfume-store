<?php
require('../connect.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Update</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
    <link rel="stylesheet" href="../assets/main.css">
    <link rel="icon" href="../assets/images/logo.ico">
    <style>
       .inn{
           display: flex;
           flex-direction: row;
           width: 400px;
           margin-left: 50px;
           margin-top: 10px;
       }
       button{
           margin-left: 50px;
       }
    </style>
</head>
<body>
<nav class="nav" id="nav">
    <div class="close" id="close">✕</div>
    <p>Hi, <?php if (isset($_COOKIE['name'])) { echo $_COOKIE['name'];} ?></p>
    <a href="../index.php">Home</a>
    <a href="../login.html">Sign in</a>
    <a href="../register.html">Sign up</a>
    <a href="#" id="brandsLink">Brands
        <ul style="margin-left: 18px; display: none;" id="brandsList">
            <li style="margin-bottom: 10px"><a href="../brand1.php">Chanel</a></li>
            <li><a href="../brand2.php">Bvlgari</a></li>
        </ul>
    </a>
    <a href="cookienull.php"><?php if (isset($_COOKIE['name'])) { echo 'Log out';} ?></a>
</nav>

<div class="wrapper">
    <div class="container menu-head">
        <header>
            <div class="menu" id="open">
                <div class="menu-line"></div>
                <div class="menu-line"></div>
                <div class="menu-line"></div>
            </div>
            <a href="../index.php" class="logo">W - Arômes</a>
            <div class="svg-icons">
                <form class="search" action="search.php" method="post">
                    <input type="text" name="Searchbox" class="search-box" placeholder="  Search...">
                    <input type="submit" name="submit" hidden>
                </form>
                    <div class="search-container">
                        <a><img src="../assets//images/search.svg" alt="Search bar"></a>
                    </div>
                    <div class="bag-container">
                        <a href="bag.php"><img src="../assets//images/bag.svg" alt="Shopping bag"></a>
                    </div>
                </div>
    </div>

<?php
$id = $_POST['id'];
$sql = "SELECT * FROM products WHERE prod_id='$id'";
$result = mysqli_query($conn,$sql);
$article = mysqli_fetch_all($result);
?>
<div class="container">
<form action="updateProduct.php" method="post">
    <h1 class="form-title">Editing product</h1>
    <div class="form-group">
        <label>Id</label>
        <input type="text" name="id" class="input-text" value="<?=$_POST['id']?> ">
    </div>
    <div class="form-group">
        <label>Name</label>
        <input type="text" name="prod_name" class="input-text" value="<?=$article[0][3]?>">
    </div>
    <div class="form-group">
        <label>Link to image</label>
        <input type="text" name="img" class="input-text" value="<?=$article[0][2]?>">
    </div>
    <div class="form-group">
        <label>Brand</label>
        <input type="text" name="prod_brand" class="input-text" value="<?=$article[0][5]?>">
    </div>
    <div class="form-group">
        <label>Price</label>
        <input type="text" name="price" class="input-text" value="<?=$article[0][4]?>">
    </div>
    <div class="form-group">
        <label>Rating</label>
        <input type="text" name="rating" class="input-text" value="<?=$article[0][6]?>">
    </div>
    <div class="form-group">
        <label>Description</label>
        <input type="text" name="desc" class="input-text"  value="<?=$article[0][1]?>">
    </div>

    <input type="submit" class="form-submit" value="Update" name="submit">
</form>
</div>

<?php
if(isset($_POST['submit'])) {
    $id=$_POST['id'];
    $prod_name = $_POST['prod_name'];
    $prod_img = $_POST['img'];
    $price = $_POST['price'];
    $brand = $_POST['prod_brand'];
    $description = $_POST['desc'];
    $rating = $_POST['rating'];

    $sql = "UPDATE products SET description='$description',prod_img='$prod_img',prod_name='$prod_name',price='$price',brand='$brand',rating='$rating' WHERE prod_id='$id'";

    $result = mysqli_query($conn, $sql);
    if (mysqli_error($conn)) {

        echo 'the error of mysql ' . mysqli_error($conn);
    } else {
        header("Location: ../indexAdmin.php");

    }
}
?>
    <div class="black-bg">
        <div class="container">
            <footer>
                <h3 class="logo">W - Arômes</h3>
                <h3>© Аll rights reserved</h3>
            </footer>
        </div>
    </div>

    <script src="../assets/main.js"></script>
</body>
</html>
