<?php
require('connect.php');
?>
<?php
$id = $_POST["id"];

$sql = "DELETE from basket WHERE order_id = '$id'";

$result = mysqli_query($conn,$sql);
if (mysqli_error($conn)) {

    echo 'the error of mysql '.mysqli_error($conn);
}
else{
    header("Location: bag.php");

}
?>
