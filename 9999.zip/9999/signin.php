<?php

include 'connect.php';

$email = $_POST['email'];
$password = $_POST['password'];


$sql = "select * from users where email = '".$email."' and password = '".$password."'";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
$count = mysqli_num_rows($result);

if ($count == 1) {
    setcookie('user_id', $row['user_id'], time() + 360, "/");
    setcookie('name', $row['name'], time() + 360, "/");
    setcookie('admin', $row['type'], time() + 360, "/");
    if ($row['type'] == "admin"){
        header('Location: /9999/indexAdmin.php');
    }else{
        header('Location: /9999/index.php');
    }
} else {
    header('Location: /9999/login.html');
}
?>