<?php
require ('connect.php');
if (isset($_COOKIE['user_id'])) {
    $id = $_POST['id'];
    $sql = "SELECT * FROM products WHERE prod_id='$id'";
    $result = mysqli_query($conn, $sql);
    $article = mysqli_fetch_all($result);

    $users_id = $_COOKIE['user_id'];
    $sql = "INSERT INTO basket (order_id, description, prod_img, prod_name, price, brand, rating,users_id) VALUES ('','" . $article[0][1] . "', '" . $article[0][2] . "', '" . $article[0][3] . "', '" . $article[0][4] . "', '" . $article[0][5] . "', '" . $article[0][6] . "','" . $users_id . "')";
    $result = mysqli_query($conn, $sql);
    if (mysqli_error($conn)) {
        echo 'the error of mysql ' . mysqli_error($conn);
    } else {
        header('Location:bag.php');
    }
}
else{
    print'<!DOCTYPE html>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="assets/main.css">
    <link rel="icon" href="assets/images/logo.ico">
</head>
<style>
    .cartview{ 
        width: 510px;
        height: 734px;
        padding: 200px 1px;
        font-size:30px;
        margin-left: 140px;
    }
</style>
<body>

    <nav class="nav" id="nav">
        <div class="close" id="close">✕</div>
<a href="index.php">Home</a>
<a href="login.html">Sign in</a>
<a href="register.html">Sign up</a>
<a href="#" id="brandsLink">Brands
    <ul style="margin-left: 18px; display: none;" id="brandsList">
        <li style="margin-bottom: 10px"><a href="brand1.php">Chanel</a></li>
        <li><a href="brand2.php">Bvlgari</a></li>
    </ul>
</a>
</nav>

<div class="wrapper">
    <div class="container menu-head">
        <header>
            <div class="menu" id="open">
                <div class="menu-line"></div>
                <div class="menu-line"></div>
                <div class="menu-line"></div>
            </div>
            <a href="index.php" class="logo">W - Arômes</a>
            <div class="svg-icons">
                    <input type="text" name="Searchbox" class="search-box" placeholder="  Search...">
                    <div class="search-container">
                        <a><img src="assets//images/search.svg" alt="Search bar"></a>
                    </div>
                    <div class="bag-container">
                        <a href="bag.php"><img src="assets//images/bag.svg" alt="Shopping bag"></a>
                    </div>
                </div>
        </header>
    </div>
    <div class="cartview">To add product to the shopping cart <a href="login.html">log in</a> or <a href="register.html">register</a></div>
      <div class="black-bg">
        <div class="container">
            <footer>
                <h3 class="logo">W - Arômes</h3>
                <h3>© Аll rights reserved</h3>
            </footer>
        </div>
    </div>

<script src="assets/main.js"></script>
</body>
</html>';
}
?>