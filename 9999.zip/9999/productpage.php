<?php
require('connect.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="assets/main.css">
    <link rel="icon" href="assets/images/logo.ico">
</head>
<style>
    form{
        max-width: none;
        margin-top: 62px;
    }
</style>
<body>

    <nav class="nav" id="nav">
        <div class="close" id="close">✕</div>
        <p><?php if (isset($_COOKIE['name'])) { echo 'Hi, '.$_COOKIE['name'];} ?></p>
        <a href="index.php">Home</a>
        <a href="login.html">Sign in</a>
        <a href="register.html">Sign up</a>
        <a href="#" id="brandsLink">Brands
            <ul style="margin-left: 18px; display: none;" id="brandsList">
                <li style="margin-bottom: 10px"><a href="brand1.php">Chanel</a></li>
                <li><a href="brand2.php">Bvlgari</a></li>
            </ul>
        </a>
        <a href="cookienull.php"><?php if (isset($_COOKIE['name'])) { echo 'Log out';} ?></a>
    </nav>
    
    <div class="wrapper">
        <div class="container menu-head">
            <header>
                <div class="menu" id="open">
                    <div class="menu-line"></div>
                    <div class="menu-line"></div>
                    <div class="menu-line"></div>
                </div>
                <a href="index.php" class="logo">W - Arômes</a>
                <div class="svg-icons">
                    <form class="search" action="search.php" method="post">
                        <input type="text" name="Searchbox" class="search-box" placeholder="  Search..." autocomplete="off">
                        <input type="submit" name="submit" hidden>
                    </form>
                    <div class="search-container">
                        <a><img src="assets//images/search.svg" alt="Search bar"></a>
                    </div>
                    <div class="bag-container">
                        <a href="bag.php"><img src="assets//images/bag.svg" alt="Shopping bag"></a>
                    </div>
                </div>
            </header>
        </div>

        <div class="main-product">
        <?php
        $id = $_POST['id'];
        $sql = "SELECT * FROM products WHERE prod_id='$id'";
        $result = mysqli_query($conn,$sql);
        $article = mysqli_fetch_all($result);
            if (mysqli_error($conn)) {
                 echo 'the error of mysql '.mysqli_error($conn);
            }
            else {
                    for ($i = 0; $i < count($article); $i++) {
                        print'<div class="image-product">
                <img src="' . $article[$i][2] . '">
            </div>
            <div class="content-product">
                <h1>' . $article[$i][3] . '</h1>
                <h2>' . $article[$i][4] . '$</h2>
                <p>' . $article[$i][1] . '</p>
                <br><br>
                <form action="addtobag.php" method="post">
              <input type="text" name="id"  value="' . $article[$i][0] . '" hidden>
            <button>Add to bag →</button>
       </form>
            </div>
        </div>';

                }
            }
        ?>
    </div>

    <div class="black-bg">
        <div class="container">
            <footer>
                <h3 class="logo">W - Arômes</h3>
                <h3>© Аll rights reserved</h3>
            </footer>
        </div>
    </div>

<script src="assets/main.js"></script>
</body>
</html>