<?php

$host ="localhost";
$user = 'root';
$pass = '';
$name  ='webproject';

$conn = mysqli_connect($host,$user,$pass,$name);

if (mysqli_connect_error()) {
    echo 'the error of the connection is '.mysqli_connect_error();
}


?>