<?php
include 'connect.php';
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$name = $_POST['name'];
$email = $_POST['email'];
$password = $_POST['password'];
$confirm = $_POST['confirmPassword'];
if($password == $confirm){
    $sql = "select * from users where email = '$email'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
    $count = mysqli_num_rows($result);
    if($count == 0){
        $sql = "INSERT INTO users(email, name,password, type) VALUES ('".$email."','".$name."','".$password."','user')";
        if(mysqli_query($conn, $sql)){
            header('Location: /9999/login.html');
        } else{
            echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
        }
    }
    else{
        echo "<h1> Login failed. Invalid username or password.</h1>";
    }
}