<?php
require('connect.php');
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="assets/main.css">
    <link rel="icon" href="assets/images/logo.ico">
</head>
<style>
    form{
        width: 187px;
        margin-left:-3px;
    }
    .cartview{
        width: 500px;
        height: 550px;
        padding: 200px 50px;
        font-size:30px;
    }
</style>
<body>

    <nav class="nav" id="nav">
        <div class="close" id="close">✕</div>
        <p><?php if (isset($_COOKIE['name'])) { echo 'Hi, '.$_COOKIE['name'];} ?></p>
        <a href="index.php">Home</a>
        <a href="login.html">Sign in</a>
        <a href="register.html">Sign up</a>
        <a href="#" id="brandsLink">Brands
            <ul style="margin-left: 18px; display: none;" id="brandsList">
                <li style="margin-bottom: 10px"><a href="brand1.php">Chanel</a></li>
                <li><a href="brand2.php">Bvlgari</a></li>
            </ul>
        </a>
        <a href="cookienull.php"><?php if (isset($_COOKIE['name'])) { echo 'Log out';} ?></a>
    </nav>
    
    <div class="wrapper">
        <div class="container menu-head">
            <header>
                <div class="menu" id="open">
                    <div class="menu-line"></div>
                    <div class="menu-line"></div>
                    <div class="menu-line"></div>
                </div>
                <a href="index.php" class="logo">W - Arômes</a>
                <div class="svg-icons">
                    <form class="search" action="search.php" method="post">
                        <input type="text" name="Searchbox" class="search-box" placeholder="  Search...">
                        <input type="submit" name="submit" hidden>
                    </form>
                    <div class="search-container">
                        <a><img src="assets//images/search.svg" alt="Search bar"></a>
                    </div>
                    <div class="bag-container">
                        <a href="bag.php"><img src="assets//images/bag.svg" alt="Shopping bag"></a>
                    </div>
                </div>
            </header>
        </div>

        <div class="bag-list">
            <?php if (isset($_COOKIE['user_id'])) {
                $users_id = $_COOKIE['user_id'];
                $sql = "SELECT * FROM basket WHERE users_id='$users_id'";
                $result = mysqli_query($conn, $sql);
                $article = mysqli_fetch_all($result);
                $sql2 = "SELECT SUM(price) AS value_sum FROM basket WHERE users_id='$users_id'";
                $result2 = mysqli_query($conn, $sql2);
                $row = mysqli_fetch_assoc($result2);
                $sum = $row['value_sum'];
                $f = sprintf ("%.1f",$sum);
                $rounded = round($f, 1);
                if (mysqli_error($conn)) {
                    echo 'the error of mysql ' . mysqli_error($conn);
                } else {
                    echo '<h1 > Total price: <span >'.floatval($rounded).'</span >$</h1 >';
                    for ($i = 0; $i < count($article); $i++) {
                        print'<div class="bag-item">
              <img src="' . $article[$i][2] . '">
                <div class="bag-item-content">
                    <h1>' . $article[$i][3] . '</h1>
                    <h2>' . $article[$i][4] . '$</h2>
                    <p>' . $article[$i][1] . '</p>
                    <form action="deleteProductFromBag.php" method="post">
              <input type="text" name="id"  value="' . $article[$i][0] . '" hidden>
            <button>Delete from bag</button>
            </form>
                </div>
            </div>';
                    }
                }
                print'</div>';}
                else{
                    print'<div class="cartview"><p>To view your shopping cart </p><a href="login.html">log in</a><p> or </p><a href="register.html">register</a></div>';
                }
        ?>

    </div>

    <div class="black-bg">
        <div class="container">
            <footer>
                <h3 class="logo">W - Arômes</h3>
                <h3>© Аll rights reserved</h3>
            </footer>
        </div>
    </div>

<script src="assets/main.js"></script>
</body>
</html>
